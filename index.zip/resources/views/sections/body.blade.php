<!-- ========================= about-section start ========================= -->
<section id="about" class="about-section pt-40">
    @include('pages.profil')
</section>
<!-- ========================= about-section end ========================= -->

<!-- ========================= blog-section start ========================= -->
<section id="blog" class="blog-section pt-60">
    @include('pages.agenda')
</section>
<!-- ========================= blog-section end ========================= -->

<!--========================= service-section start ========================= -->
<section id="services" class="service-section pt-60">
    @include('pages.about')
</section>
<!--========================= service-section end ========================= -->

<!--========================= we-do-section start========================= -->
<section id="contact" class="we-do-section pt-60">
    @include('pages.partners')
</section>
<!--========================= we-do-section start========================= -->
