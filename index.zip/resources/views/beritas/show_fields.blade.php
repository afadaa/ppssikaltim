<!-- Thumbnail Field -->
<div class="col-sm-12">
    {!! Form::label('thumbnail', 'Thumbnail:') !!}
    <p>{{ $berita->thumbnail }}</p>
</div>

<!-- Tittle Field -->
<div class="col-sm-12">
    {!! Form::label('tittle', 'Tittle:') !!}
    <p>{{ $berita->tittle }}</p>
</div>

<!-- Desc Field -->
<div class="col-sm-12">
    {!! Form::label('desc', 'Desc:') !!}
    <p>{{ $berita->desc }}</p>
</div>

<!-- Slug Field -->
<div class="col-sm-12">
    {!! Form::label('slug', 'Slug:') !!}
    <p>{{ $berita->slug }}</p>
</div>

