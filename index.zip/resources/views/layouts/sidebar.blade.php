<div class="navbar-nav w-100">
    <a href="{{ url('/home') }}" class="nav-item nav-link active"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
    
    @include('layouts.menu')
    
</div>