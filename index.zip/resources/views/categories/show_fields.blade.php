<!-- Tittle Field -->
<div class="col-sm-12">
    {!! Form::label('tittle', 'Tittle:') !!}
    <p>{{ $categories->tittle }}</p>
</div>

<!-- Desc Field -->
<div class="col-sm-12">
    {!! Form::label('desc', 'Desc:') !!}
    <p>{{ $categories->desc }}</p>
</div>

<!-- Status Field -->
<div class="col-sm-12">
    {!! Form::label('status', 'Status:') !!}
    <p>{{ $categories->status }}</p>
</div>

<!-- Link Field -->
<div class="col-sm-12">
    {!! Form::label('link', 'Link:') !!}
    <p>{{ $categories->link }}</p>
</div>

<!-- Slug Field -->
<div class="col-sm-12">
    {!! Form::label('slug', 'Slug:') !!}
    <p>{{ $categories->slug }}</p>
</div>

<!-- Parent Id Field -->
<div class="col-sm-12">
    {!! Form::label('parent_id', 'Parent Id:') !!}
    <p>{{ $categories->parent_id }}</p>
</div>

<!-- Categoriescol Field -->
<div class="col-sm-12">
    {!! Form::label('categoriescol', 'Categoriescol:') !!}
    <p>{{ $categories->categoriescol }}</p>
</div>

