<!-- Thumbnail Field -->
<div class="col-sm-12">
    {!! Form::label('thumbnail', 'Thumbnail:') !!}
    <p>{{ $partner->thumbnail }}</p>
</div>

<!-- Tittle Field -->
<div class="col-sm-12">
    {!! Form::label('tittle', 'Tittle:') !!}
    <p>{{ $partner->tittle }}</p>
</div>

<!-- Link Field -->
<div class="col-sm-12">
    {!! Form::label('link', 'Link:') !!}
    <p>{{ $partner->link }}</p>
</div>

