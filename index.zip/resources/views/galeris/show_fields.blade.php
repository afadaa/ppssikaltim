<!-- Tittle Field -->
<div class="col-sm-12">
    {!! Form::label('tittle', 'Tittle:') !!}
    <p>{{ $galeri->tittle }}</p>
</div>

<!-- Photo Field -->
<div class="col-sm-12">
    {!! Form::label('photo', 'Photo:') !!}
    <p>{{ $galeri->photo }}</p>
</div>

