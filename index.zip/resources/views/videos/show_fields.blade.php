<!-- Tittle Field -->
<div class="col-sm-12">
    {!! Form::label('tittle', 'Tittle:') !!}
    <p>{{ $video->tittle }}</p>
</div>

<!-- Link Field -->
<div class="col-sm-12">
    {!! Form::label('link', 'Link:') !!}
    <p>{{ $video->link }}</p>
</div>

