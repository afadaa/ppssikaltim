@extends('master')

@section('header')
<!-- ========================= header start ========================= -->

<!-- ========================= header end ========================= -->
@endsection

@section('blog')
  @include('sections.body')    
@endsection
