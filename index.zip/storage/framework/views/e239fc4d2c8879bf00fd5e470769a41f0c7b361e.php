<!-- Thumbnail Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('thumbnail', 'Thumbnail:'); ?>

    <br>
    <?php echo Form::file('thumbnail', null, ['class' => 'form-control','maxlength' => 255]); ?>

</div>

<!-- Tittle Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tittle', 'Tittle:'); ?>

    <?php echo Form::text('tittle', null, ['class' => 'form-control','maxlength' => 255, 'required']); ?>

</div>

<!-- Desc Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('desc', 'Desc:'); ?>

    <?php echo Form::textarea('desc', null, ['class' => 'form-control','id' => 'my-editor', 'required']); ?>

</div>

<!-- Categories Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('categories', 'Kategori:'); ?>

    <?php echo Form::select('categories', ['Profil' => 'Profile', 'About' => 'About', 'Layanan'=>'Service'], null, ['class' => 'form-control','maxlength' => 255,'maxlength' => 255]); ?>

</div><?php /**PATH D:\Website\PPSSI\resources\views/layanans/fields.blade.php ENDPATH**/ ?>