<table class="table" id="agendas-table">
    <thead>
    <tr>
        <th>#</th>
        <th>Thumbnail</th>
        <th>Tittle</th>
        <th>Desc</th>
        <th>Quota</th>
        <th>Slug</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
        <?php
            $i=1;
        ?> 
    <?php $__currentLoopData = $agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($agenda->thumbnail); ?></td>
            <td><?php echo $agenda->tittle; ?></td>
            <td><?php echo Str::limit($agenda->desc, 95, '...'); ?></td>
            <td><?php echo e($agenda->quota); ?></td>
            <td><?php echo e($agenda->slug); ?></td>
            <td width="120">
                <?php echo Form::open(['route' => ['agendas.destroy', $agenda->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo e(route('agendas.show', [$agenda->id])); ?>"
                       class='btn btn-default btn-xs'>
                        <i class="far fa-eye"></i>
                    </a>
                    <a href="<?php echo e(route('agendas.edit', [$agenda->id])); ?>"
                       class='btn btn-default btn-xs'>
                        <i class="far fa-edit"></i>
                    </a>
                    <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\Website\PPSSI\resources\views/agendas/table.blade.php ENDPATH**/ ?>