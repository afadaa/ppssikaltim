<table class="table" id="beritas-table">
    <thead>
    <tr>
        <th>#</th>
        <th>Thumbnail</th>
        <th>Tittle</th>
        <th>Desc</th>
        <th>Slug</th>
        <th colspan="3">Action</th>
    </tr>
    </thead>
    <tbody>
        <?php
            $i=1;
        ?>
    <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><img src="<?php echo e($berita->thumbnail); ?>" alt="Thumbnail" width="20%"></td>
            <td><?php echo e($berita->tittle); ?></td>
            <td><?php echo Str::limit($berita->desc, 50, '...'); ?></td>
            <td><?php echo e($berita->slug); ?></td>
            <td width="120">
                <?php echo Form::open(['route' => ['beritas.destroy', $berita->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo e(route('beritas.show', [$berita->id])); ?>"
                       class='btn btn-default btn-xs'>
                        <i class="far fa-eye"></i>
                    </a>
                    <a href="<?php echo e(route('beritas.edit', [$berita->id])); ?>"
                       class='btn btn-default btn-xs'>
                        <i class="far fa-edit"></i>
                    </a>
                    <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\Website\PPSSI\resources\views/beritas/table.blade.php ENDPATH**/ ?>