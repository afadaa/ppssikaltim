<div class="table-responsive">
    <table class="table" id="layanans-table">
        <thead>
        <tr>
            <th>Thumbnail</th>
        <th>Tittle</th>
        <th>Desc</th>
        <th>Categories</th>
            <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $layanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($layanan->thumbnail); ?></td>
                <td><?php echo e($layanan->tittle); ?></td>
                <td><?php echo Str::limit($layanan->desc, 50, '...'); ?></td>
                <td><?php echo e($layanan->categories); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['layanans.destroy', $layanan->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('layanans.show', [$layanan->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('layanans.edit', [$layanan->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\Website\PPSSI\resources\views/layanans/table.blade.php ENDPATH**/ ?>