<div class="navbar-nav w-100">
    <a href="<?php echo e(url('/home')); ?>" class="nav-item nav-link active"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
    
    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</div><?php /**PATH D:\Website\PPSSI\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>