<!-- ========================= about-section start ========================= -->
<section id="about" class="about-section pt-40">
    <?php echo $__env->make('pages.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<!-- ========================= about-section end ========================= -->

<!-- ========================= blog-section start ========================= -->
<section id="blog" class="blog-section pt-60">
    <?php echo $__env->make('pages.agenda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<!-- ========================= blog-section end ========================= -->

<!--========================= service-section start ========================= -->
<section id="services" class="service-section pt-60">
    <?php echo $__env->make('pages.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<!--========================= service-section end ========================= -->

<!--========================= we-do-section start========================= -->
<section id="contact" class="we-do-section pt-60">
    <?php echo $__env->make('pages.partners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<!--========================= we-do-section start========================= -->
<?php /**PATH D:\Website\PPSSI\resources\views/sections/body.blade.php ENDPATH**/ ?>