<?php $__env->startSection('header'); ?>
<!-- ========================= header start ========================= -->

<!-- ========================= header end ========================= -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('blog'); ?>
  <?php echo $__env->make('sections.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\PPSSI\resources\views/welcome.blade.php ENDPATH**/ ?>