<!-- Thumbnail Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('thumbnail', 'Thumbnail:'); ?>

    <br>
    <?php echo Form::file('thumbnail', null, ['class' => 'form-control','maxlength' => 255,'required']); ?>

</div>

<!-- Tittle Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tittle', 'Tittle:'); ?>

    <?php echo Form::text('tittle', null, ['class' => 'form-control','maxlength' => 255,'required']); ?>

</div>

<!-- Desc Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('desc', 'Desc:'); ?>

    <?php echo Form::textarea('desc', null, ['class' => 'form-control','maxlength' => 255,'id' => 'my-editor','required']); ?>

</div>

<!-- Location Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('location', 'Lokasi:'); ?>

    <?php echo Form::text('location', null, ['class' => 'form-control','required']); ?>

</div>

<!-- Quota Field -->
<div class="form-group col-sm-3">
    <?php echo Form::label('quota', 'Kuota:'); ?>

    <?php echo Form::number('quota', null, ['class' => 'form-control','required']); ?>

</div>

<!-- Gift Field -->
<div class="form-group col-sm-3">
    <?php echo Form::label('gift', 'Aksesoris:'); ?>

    <?php echo Form::text('gift', null, ['class' => 'form-control','maxlength' => 45,'maxlength' => 45]); ?>

</div>

<!-- Date Start Field -->
<div class="form-group col-sm-3">
    <?php echo Form::label('date_start', 'Date Start:'); ?>

    <input type="text" name="date_start" class="form-control" id="date_start" required>

</div>

<!-- Date End Field -->
<div class="form-group col-sm-3">
    <?php echo Form::label('date_end', 'Date End:'); ?>

    <input type="text" name="date_end" class="form-control" id="date_end" required>
</div>


<!-- Link Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('link', 'Link Pendaftaran:'); ?>

    <?php echo Form::text('link', null, ['class' => 'form-control','required']); ?>

</div><?php /**PATH D:\Website\PPSSI\resources\views/agendas/fields.blade.php ENDPATH**/ ?>