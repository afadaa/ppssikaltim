<div class="shape shape-7">
    <img src="/assets/img/shapes/shape-6.svg" alt="">
</div>
<div class="container">
    <div class="row">
        <div class="col-xl-8 mx-auto">
            <div class="section-title text-center mb-55">
                <span class="wow fadeInDown" data-wow-delay=".2s">Event Post</span>
                <h2 class="mb-15 wow fadeInUp" data-wow-delay=".4s">Event Terbaru</h2>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-4 col-lg-4 col-md-6">
            <div class="single-blog mb-30 wow fadeInUp" data-wow-delay=".4s">
                <div class="blog-img">
                    <a href="/event/<?php echo e($item->slug); ?>"><img src="<?php echo e($item->thumbnail); ?>" alt=""></a>
                </div>
                <div class="blog-content">
                    <h4><a href="/event/<?php echo e($item->slug); ?>"><?php echo e($item->tittle); ?></a></h4>
                    <p><?php echo Str::limit($item->desc, 100, '...'); ?></p>
                    <a class="read-more btn theme-btn" href="/event/<?php echo e($item->slug); ?>">Lihat Selengkapnya <i class="lni lni-arrow-right"></i></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH D:\Website\PPSSI\resources\views/pages/agenda.blade.php ENDPATH**/ ?>