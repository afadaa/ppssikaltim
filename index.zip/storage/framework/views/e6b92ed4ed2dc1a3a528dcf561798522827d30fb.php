<?php $__env->startSection('content'); ?>

    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6>Tambah Event Baru</h6>
                    <hr class="mb-2">

                    <?php echo Form::open(['route' => 'agendas.store', 'files' => true]); ?>


                    <div class="card-body">

                        <div class="row">
                            <?php echo $__env->make('agendas.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                    </div>

                    <div class="card-footer">
                        <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                        <a href="<?php echo e(route('agendas.index')); ?>" class="btn btn-default">Cancel</a>
                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $('#date_start').datetimepicker({
            format: 'YYYY-MM-DD HH:mm',
            useCurrent: true,
            sideBySide: true
        })
    </script>
    
    <script type="text/javascript">
        $('#date_end').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\PPSSI\resources\views/agendas/create.blade.php ENDPATH**/ ?>