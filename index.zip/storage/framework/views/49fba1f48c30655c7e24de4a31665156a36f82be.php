<table class="table" id="announcements-table">
    <thead>
    <tr>
        <th>#</th>
        <th>Tittle</th>
        <th>Desc</th>
        <th colspan="3">Action</th>
    </tr>
    </thead>
    <tbody>
    <?php
        $i=1;
    ?>
    <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($announcement->tittle); ?></td>
            <td><?php echo Str::limit($announcement->desc, 300); ?></td>
            <td width="120">
                <?php echo Form::open(['route' => ['announcements.destroy', $announcement->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo e(route('announcements.show', [$announcement->id])); ?>"
                       class='btn btn-default btn-xs'>
                        <i class="far fa-eye"></i>
                    </a>
                    <a href="<?php echo e(route('announcements.edit', [$announcement->id])); ?>"
                       class='btn btn-default btn-xs'>
                        <i class="far fa-edit"></i>
                    </a>
                    <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\Website\PPSSI\resources\views/announcements/table.blade.php ENDPATH**/ ?>